# I'amsterdam — Roblox startscripts

Deze map bevat werkende Luau-startscripts voor de game. Ze zijn bewust klein en leesbaar, zodat je ze in Roblox Studio makkelijk kunt aanpassen.

## Waar hoort wat?

| Bestand | Plaats in Roblox Studio | Type |
|---|---|---|
| `ReplicatedStorage/GameConfig.lua` | ReplicatedStorage → `GameConfig` | ModuleScript |
| `ReplicatedStorage/Remotes.lua` | ReplicatedStorage → `Remotes` | ModuleScript |
| `ServerScriptService/DataService.server.lua` | ServerScriptService → `DataService` | Script |
| `ServerScriptService/JobService.server.lua` | ServerScriptService → `JobService` | Script |
| `ServerScriptService/VehicleService.server.lua` | ServerScriptService → `VehicleService` | Script |
| `ServerScriptService/GamepassService.server.lua` | ServerScriptService → `GamepassService` | Script |
| `ServerScriptService/TrainService.server.lua` | ServerScriptService → `TrainService` | Script |
| `ServerScriptService/BridgeService.server.lua` | ServerScriptService → `BridgeService` | Script |
| `ServerScriptService/JobBoardSetup.server.lua` | ServerScriptService → `JobBoardSetup` | Script |
| `StarterPlayerScripts/HudClient.client.lua` | StarterPlayer → StarterPlayerScripts → `HudClient` | LocalScript |
| `StarterPlayerScripts/TaskClient.client.lua` | StarterPlayer → StarterPlayerScripts → `TaskClient` | LocalScript |

De `.lua`-inhoud plak je in een nieuw script met die naam. Werk je met Rojo, dan kun je de mappenstructuur direct syncen.

## Wat moet je in Studio zelf klaarzetten?

1. `workspace.Banenpalen` — parts (paaltjes met bordje). Naam van de part = de sleutel uit `GameConfig.Jobs`, of geef de part een StringValue `JobId`.
2. `workspace.Taakpunten` — parts waar de klus gebeurt (kassa, lopende band, brandkraan), ook met `JobId`.
3. `ServerStorage.Vehicles` — één Model per voertuig, met dezelfde naam als `Model` in `GameConfig.Vehicles`. Elk voertuig heeft minstens één `VehicleSeat`.
4. `workspace.SpawnedVehicles` — lege Folder waar opgeroepen voertuigen in komen.
5. `workspace.Trein` — Model met PrimaryPart, en `workspace.Trein_Stations` met parts `Centraal`, `Sloterdijk`, `HalfwegZwanenburg`, `Polderhalte`.
6. `workspace.Ophaalbrug` — Model met parts `Dek` en `Scharnier`.

## Voor je publiceert

- Zet in Studio: Game Settings → Security → **Enable Studio Access to API Services** aan (nodig voor opslaan van munten).
- Maak je passes aan in het Creator Dashboard en vul de echte ID's in bij `GameConfig.Gamepasses`. Een ID van `0` betekent "nog niet beschikbaar" en de game blijft gewoon werken.
- Zet de game op **Ervaringsniveau: Alle leeftijden** en laat chat op Roblox' eigen gefilterde systeem staan.

## Veiligheidsprincipes in de code

- De client vertelt nooit hoeveel geld er uitbetaald moet worden; de server bepaalt dat uit `GameConfig`.
- Elke baan heeft een cooldown, zodat een exploit-script niet oneindig kan verdienen.
- Voertuigen zijn gebonden aan één eigenaar en verdwijnen na 3 minuten.
