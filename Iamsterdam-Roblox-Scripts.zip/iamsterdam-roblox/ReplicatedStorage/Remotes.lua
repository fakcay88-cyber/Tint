--!strict
-- Remotes (ModuleScript) -> ReplicatedStorage/Remotes
-- Maakt alle RemoteEvents/Functions aan en geeft ze terug.
-- Server en client gebruiken allebei: local Remotes = require(ReplicatedStorage.Remotes)

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local folder = ReplicatedStorage:FindFirstChild("IamRemotes")
if not folder then
	folder = Instance.new("Folder")
	folder.Name = "IamRemotes"
	folder.Parent = ReplicatedStorage
end

local function ensure(className: string, name: string): Instance
	local existing = folder:FindFirstChild(name)
	if existing then
		return existing
	end
	local inst = Instance.new(className)
	inst.Name = name
	inst.Parent = folder
	return inst
end

return {
	Folder = folder,
	-- Client -> Server
	ChooseJob = ensure("RemoteEvent", "ChooseJob") :: RemoteEvent,
	QuitJob = ensure("RemoteEvent", "QuitJob") :: RemoteEvent,
	CompleteTask = ensure("RemoteEvent", "CompleteTask") :: RemoteEvent,
	SpawnVehicle = ensure("RemoteEvent", "SpawnVehicle") :: RemoteEvent,
	DespawnVehicle = ensure("RemoteEvent", "DespawnVehicle") :: RemoteEvent,
	PromptGamepass = ensure("RemoteEvent", "PromptGamepass") :: RemoteEvent,
	TeleportZone = ensure("RemoteEvent", "TeleportZone") :: RemoteEvent,
	-- Server -> Client
	CurrencyChanged = ensure("RemoteEvent", "CurrencyChanged") :: RemoteEvent,
	JobChanged = ensure("RemoteEvent", "JobChanged") :: RemoteEvent,
	Notify = ensure("RemoteEvent", "Notify") :: RemoteEvent,
	-- Two-way
	GetProfile = ensure("RemoteFunction", "GetProfile") :: RemoteFunction,
	GetOwnedPasses = ensure("RemoteFunction", "GetOwnedPasses") :: RemoteFunction,
}
