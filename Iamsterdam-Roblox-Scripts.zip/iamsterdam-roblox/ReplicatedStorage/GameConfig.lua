--!strict
-- GameConfig (ModuleScript) -> ReplicatedStorage/GameConfig
-- Central configuration for I'amsterdam. Edit values here, not in the services.

local GameConfig = {}

GameConfig.Currency = {
	Name = "Stroopwafels",
	StartingAmount = 100,
	DataStoreKeyPrefix = "iam_player_",
}

-- Zones of the map. Spawn CFrames are read from parts named
-- workspace.Zones.<Id>.Spawn so you can move them in Studio without code edits.
GameConfig.Zones = {
	{ Id = "Centrum", Display = "Amsterdam Centrum" },
	{ Id = "Noord", Display = "Amsterdam Noord" },
	{ Id = "Haven", Display = "Westpoort / Haven" },
	{ Id = "Zwanenburg", Display = "Zwanenburg" },
	{ Id = "Halfweg", Display = "Halfweg SugarCity" },
	{ Id = "Polder", Display = "De Polder" },
	{ Id = "Spaarndam", Display = "Spaarndam" },
}

-- Jobs. Each job has a payout and a cooldown (seconds) per completed task.
GameConfig.Jobs = {
	Conducteur = { Display = "NS-conducteur", Zone = "Centrum", Pay = 25, Cooldown = 8, Uniform = "Uniform_NS" },
	Machinist = { Display = "Machinist", Zone = "Centrum", Pay = 35, Cooldown = 20, Uniform = "Uniform_NS" },
	Supermarkt = { Display = "Supermarktmedewerker", Zone = "Zwanenburg", Pay = 18, Cooldown = 5, Uniform = "Uniform_Super" },
	Snoepbakker = { Display = "Snoepbakker SugarCity", Zone = "Halfweg", Pay = 30, Cooldown = 10, Uniform = "Uniform_Bakker" },
	Bootkapitein = { Display = "Grachtenbootkapitein", Zone = "Centrum", Pay = 28, Cooldown = 12, Uniform = "Uniform_Kapitein" },
	Politie = { Display = "Politieagent", Zone = "Haven", Pay = 26, Cooldown = 10, Uniform = "Uniform_Politie" },
	Brandweer = { Display = "Brandweer", Zone = "Haven", Pay = 26, Cooldown = 10, Uniform = "Uniform_Brandweer" },
	Dokter = { Display = "Dokter", Zone = "Centrum", Pay = 27, Cooldown = 10, Uniform = "Uniform_Dokter" },
	Bakker = { Display = "Poffertjesbakker", Zone = "Centrum", Pay = 20, Cooldown = 6, Uniform = "Uniform_Bakker" },
	Bloemenkweker = { Display = "Bloemenkweker", Zone = "Polder", Pay = 22, Cooldown = 8, Uniform = "Uniform_Kweker" },
	Boer = { Display = "Boer", Zone = "Polder", Pay = 24, Cooldown = 9, Uniform = "Uniform_Boer" },
	Kraanmachinist = { Display = "Havenkraanmachinist", Zone = "Haven", Pay = 32, Cooldown = 14, Uniform = "Uniform_Haven" },
	Brugwachter = { Display = "Brugwachter", Zone = "Zwanenburg", Pay = 21, Cooldown = 12, Uniform = "Uniform_Brug" },
	Dierenverzorger = { Display = "Dierenverzorger", Zone = "Centrum", Pay = 22, Cooldown = 9, Uniform = "Uniform_Artis" },
	Leraar = { Display = "Leraar", Zone = "Zwanenburg", Pay = 20, Cooldown = 15, Uniform = "Uniform_School" },
	Fietsenmaker = { Display = "Fietsenmaker", Zone = "Centrum", Pay = 19, Cooldown = 7, Uniform = "Uniform_Fiets" },
	Bezorger = { Display = "Bakfietsbezorger", Zone = "Zwanenburg", Pay = 23, Cooldown = 10, Uniform = "Uniform_Bezorger" },
	Straatartiest = { Display = "Straatartiest", Zone = "Centrum", Pay = 15, Cooldown = 6, Uniform = "Uniform_Artiest" },
}

-- Vehicles. Models live in ServerStorage/Vehicles/<ModelName>.
GameConfig.Vehicles = {
	Omafiets = { Display = "Omafiets", Model = "Omafiets", Price = 0, Seats = 1, Water = false },
	Bakfiets = { Display = "Bakfiets", Model = "Bakfiets", Price = 0, Seats = 4, Water = false },
	Step = { Display = "Step", Model = "Step", Price = 0, Seats = 1, Water = false },
	Tandem = { Display = "Tandem", Model = "Tandem", Price = 250, Seats = 2, Water = false },
	Snorscooter = { Display = "Snorscooter", Model = "Snorscooter", Price = 600, Seats = 2, Water = false },
	Sloep = { Display = "Grachtenbootje", Model = "Sloep", Price = 800, Seats = 4, Water = true },
	Waterfiets = { Display = "Zwaan-waterfiets", Model = "Waterfiets", Price = 400, Seats = 2, Water = true },
	Rondvaartboot = { Display = "Rondvaartboot", Model = "Rondvaartboot", Price = 0, Seats = 8, Water = true, GamepassId = 0 },
	Tulpenfiets = { Display = "Zwevende Tulpenfiets", Model = "Tulpenfiets", Price = 0, Seats = 1, Water = false, GamepassId = 0 },
	Suikerspinkar = { Display = "Suikerspin-karretje", Model = "Suikerspinkar", Price = 0, Seats = 1, Water = false, GamepassId = 0 },
}

GameConfig.VehicleDespawnSeconds = 180
GameConfig.VehicleCooldownSeconds = 20 -- 0 met de "Skip de wachttijd" pass

-- VUL HIER JE ECHTE GAMEPASS-ID'S IN (Creator Dashboard -> Passes).
GameConfig.Gamepasses = {
	GoudenGrachtenpand = { Id = 0, Display = "Gouden Grachtenpand", Robux = 599 },
	VillaRingvaart = { Id = 0, Display = "Villa aan de Ringvaart", Robux = 799 },
	SnoepPenthouse = { Id = 0, Display = "Snoepfabriek-penthouse", Robux = 699 },
	Woonboot = { Id = 0, Display = "Woonboot", Robux = 399 },
	Rondvaartboot = { Id = 0, Display = "Rondvaartboot-kapitein", Robux = 349 },
	Tulpenfiets = { Id = 0, Display = "Zwevende Tulpenfiets", Robux = 299 },
	Suikerspinkar = { Id = 0, Display = "Suikerspin-karretje", Robux = 249 },
	Tram = { Id = 0, Display = "Klassieke Tram-eigenaar", Robux = 449 },
	PetsGracht = { Id = 0, Display = "Huisdieren: Grachtenvriendjes", Robux = 399 },
	PetsPolder = { Id = 0, Display = "Huisdieren: Polderdieren", Robux = 399 },
	VliegendeZwaan = { Id = 0, Display = "Vliegende Zwaan", Robux = 549 },
	EmotesNL = { Id = 0, Display = "Emotes: Typisch Nederlands", Robux = 199 },
	Kledingkist = { Id = 0, Display = "Hollandse Kledingkist", Robux = 249 },
	MeubelsDeluxe = { Id = 0, Display = "Huisinrichting Deluxe", Robux = 399 },
	SkipWachttijd = { Id = 0, Display = "Skip de wachttijd", Robux = 149 },
	ExtraHuisslot = { Id = 0, Display = "Extra huisslot", Robux = 199 },
	Radio = { Id = 0, Display = "Radio in elk voertuig", Robux = 149 },
	VIP = { Id = 0, Display = "VIP Amsterdammer", Robux = 899 },
}

GameConfig.VipMultiplier = 2

-- Treinroute: parts in workspace.Trein.Stations, in volgorde.
GameConfig.Train = {
	Stations = { "Centraal", "Sloterdijk", "HalfwegZwanenburg", "Polderhalte" },
	DwellSeconds = 15,
	Speed = 45, -- studs per seconde
}

return GameConfig
