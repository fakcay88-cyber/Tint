--!strict
-- HudClient (LocalScript) -> StarterPlayer/StarterPlayerScripts/HudClient
-- Kleurrijke HUD met munten, huidige baan, voertuigmenu en meldingen.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

local GameConfig = require(ReplicatedStorage:WaitForChild("GameConfig"))
local Remotes = require(ReplicatedStorage:WaitForChild("Remotes"))

local player = Players.LocalPlayer
local gui = Instance.new("ScreenGui")
gui.Name = "IamHud"
gui.ResetOnSpawn = false
gui.IgnoreGuiInset = true
gui.Parent = player:WaitForChild("PlayerGui")

local ORANGE = Color3.fromRGB(255, 138, 40)
local DEEP = Color3.fromRGB(28, 42, 82)
local CREAM = Color3.fromRGB(255, 249, 235)

local function round(instance: Instance, radius: number)
	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(0, radius)
	corner.Parent = instance
end

-- Muntenteller
local coinFrame = Instance.new("Frame")
coinFrame.Size = UDim2.fromOffset(220, 52)
coinFrame.Position = UDim2.new(0, 16, 0, 56)
coinFrame.BackgroundColor3 = CREAM
coinFrame.BorderSizePixel = 0
coinFrame.Parent = gui
round(coinFrame, 16)

local coinLabel = Instance.new("TextLabel")
coinLabel.Size = UDim2.fromScale(1, 1)
coinLabel.BackgroundTransparency = 1
coinLabel.Font = Enum.Font.FredokaOne
coinLabel.TextSize = 24
coinLabel.TextColor3 = DEEP
coinLabel.Text = "0 " .. GameConfig.Currency.Name
coinLabel.Parent = coinFrame

-- Baanlabel
local jobLabel = Instance.new("TextLabel")
jobLabel.Size = UDim2.fromOffset(260, 40)
jobLabel.Position = UDim2.new(0, 16, 0, 116)
jobLabel.BackgroundColor3 = ORANGE
jobLabel.BorderSizePixel = 0
jobLabel.Font = Enum.Font.FredokaOne
jobLabel.TextSize = 20
jobLabel.TextColor3 = Color3.new(1, 1, 1)
jobLabel.Text = "Geen baan gekozen"
jobLabel.Parent = gui
round(jobLabel, 14)

-- Voertuigknoppen
local vehicleList = Instance.new("Frame")
vehicleList.Size = UDim2.fromOffset(180, 300)
vehicleList.AnchorPoint = Vector2.new(1, 0.5)
vehicleList.Position = UDim2.new(1, -16, 0.5, 0)
vehicleList.BackgroundTransparency = 1
vehicleList.Parent = gui

local layout = Instance.new("UIListLayout")
layout.Padding = UDim.new(0, 8)
layout.HorizontalAlignment = Enum.HorizontalAlignment.Right
layout.Parent = vehicleList

local function addVehicleButton(vehicleId: string, config: any)
	local button = Instance.new("TextButton")
	button.Size = UDim2.fromOffset(180, 40)
	button.BackgroundColor3 = CREAM
	button.BorderSizePixel = 0
	button.Font = Enum.Font.FredokaOne
	button.TextSize = 16
	button.TextColor3 = DEEP
	button.Text = config.Display
	button.Parent = vehicleList
	round(button, 12)

	button.MouseButton1Click:Connect(function()
		Remotes.SpawnVehicle:FireServer(vehicleId)
	end)
end

for vehicleId, config in GameConfig.Vehicles do
	addVehicleButton(vehicleId, config)
end

-- Meldingen
local toast = Instance.new("TextLabel")
toast.Size = UDim2.fromOffset(420, 48)
toast.AnchorPoint = Vector2.new(0.5, 0)
toast.Position = UDim2.new(0.5, 0, 0, -60)
toast.BackgroundColor3 = DEEP
toast.BorderSizePixel = 0
toast.Font = Enum.Font.FredokaOne
toast.TextSize = 20
toast.TextColor3 = Color3.new(1, 1, 1)
toast.Text = ""
toast.Parent = gui
round(toast, 16)

local function showToast(message: string)
	toast.Text = message
	TweenService:Create(toast, TweenInfo.new(0.3), { Position = UDim2.new(0.5, 0, 0, 24) }):Play()
	task.delay(2.5, function()
		TweenService:Create(toast, TweenInfo.new(0.3), { Position = UDim2.new(0.5, 0, 0, -60) }):Play()
	end)
end

Remotes.CurrencyChanged.OnClientEvent:Connect(function(amount)
	coinLabel.Text = ("%d %s"):format(amount, GameConfig.Currency.Name)
end)

Remotes.JobChanged.OnClientEvent:Connect(function(jobId)
	local job = jobId and GameConfig.Jobs[jobId]
	jobLabel.Text = job and ("Baan: " .. job.Display) or "Geen baan gekozen"
end)

Remotes.Notify.OnClientEvent:Connect(showToast)

Remotes.PromptGamepass.OnClientEvent:Connect(function(passId)
	if passId and passId ~= 0 then
		game:GetService("MarketplaceService"):PromptGamePassPurchase(player, passId)
	else
		showToast("Deze pass komt binnenkort!")
	end
end)

-- Beginwaarden ophalen
task.spawn(function()
	local profile = Remotes.GetProfile:InvokeServer()
	if profile then
		coinLabel.Text = ("%d %s"):format(profile.coins, GameConfig.Currency.Name)
		local job = profile.job and GameConfig.Jobs[profile.job]
		jobLabel.Text = job and ("Baan: " .. job.Display) or "Geen baan gekozen"
	end
end)
