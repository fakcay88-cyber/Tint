--!strict
-- TaskClient (LocalScript) -> StarterPlayer/StarterPlayerScripts/TaskClient
-- Koppelt taakpunten in de wereld (ProximityPrompts) aan je gekozen baan.
-- Verwacht: parts in workspace.Taakpunten met een StringValue "JobId".

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Remotes = require(ReplicatedStorage:WaitForChild("Remotes"))
local GameConfig = require(ReplicatedStorage:WaitForChild("GameConfig"))

local currentJob: string? = nil
Remotes.JobChanged.OnClientEvent:Connect(function(jobId)
	currentJob = jobId
end)

local folder = workspace:WaitForChild("Taakpunten")

local function hook(part: Instance)
	if not part:IsA("BasePart") then
		return
	end
	local idValue = part:FindFirstChild("JobId") :: StringValue?
	local jobId = idValue and idValue.Value or part.Name
	local job = GameConfig.Jobs[jobId]
	if not job then
		return
	end

	local prompt = part:FindFirstChildOfClass("ProximityPrompt") or Instance.new("ProximityPrompt")
	prompt.ActionText = "Doe de klus"
	prompt.ObjectText = job.Display
	prompt.HoldDuration = 0.8
	prompt.MaxActivationDistance = 10
	prompt.Parent = part

	prompt.Triggered:Connect(function()
		if currentJob ~= jobId then
			Remotes.Notify:FireServer() -- geen effect; server negeert
			return
		end
		Remotes.CompleteTask:FireServer()
	end)
end

for _, child in folder:GetChildren() do
	hook(child)
end
folder.ChildAdded:Connect(hook)
