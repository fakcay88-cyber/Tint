--!strict
-- DataService (Script) -> ServerScriptService/DataService
-- Slaat munten, baan en gekochte spullen op per speler.

local Players = game:GetService("Players")
local DataStoreService = game:GetService("DataStoreService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local GameConfig = require(ReplicatedStorage:WaitForChild("GameConfig"))
local Remotes = require(ReplicatedStorage:WaitForChild("Remotes"))

local store = DataStoreService:GetDataStore("IamsterdamPlayers_v1")

export type Profile = {
	coins: number,
	job: string?,
	houseZone: string?,
	vehiclesOwned: { [string]: boolean },
	playtime: number,
}

local profiles: { [Player]: Profile } = {}

local function defaultProfile(): Profile
	return {
		coins = GameConfig.Currency.StartingAmount,
		job = nil,
		houseZone = nil,
		vehiclesOwned = { Omafiets = true, Bakfiets = true, Step = true },
		playtime = 0,
	}
end

local function key(player: Player): string
	return GameConfig.Currency.DataStoreKeyPrefix .. player.UserId
end

function _G.IamGetProfile(player: Player): Profile?
	return profiles[player]
end

function _G.IamAddCoins(player: Player, amount: number)
	local profile = profiles[player]
	if not profile then
		return
	end
	profile.coins += math.floor(amount)
	Remotes.CurrencyChanged:FireClient(player, profile.coins)
end

function _G.IamSpendCoins(player: Player, amount: number): boolean
	local profile = profiles[player]
	if not profile or profile.coins < amount then
		return false
	end
	profile.coins -= amount
	Remotes.CurrencyChanged:FireClient(player, profile.coins)
	return true
end

local function load(player: Player)
	local ok, data = pcall(function()
		return store:GetAsync(key(player))
	end)
	local profile: Profile = (ok and typeof(data) == "table") and (data :: any) or defaultProfile()
	profile.vehiclesOwned = profile.vehiclesOwned or {}
	profiles[player] = profile
	Remotes.CurrencyChanged:FireClient(player, profile.coins)
	Remotes.JobChanged:FireClient(player, profile.job)
end

local function save(player: Player)
	local profile = profiles[player]
	if not profile then
		return
	end
	pcall(function()
		store:SetAsync(key(player), profile)
	end)
	profiles[player] = nil
end

Players.PlayerAdded:Connect(load)
Players.PlayerRemoving:Connect(save)
game:BindToClose(function()
	for _, player in Players:GetPlayers() do
		save(player)
	end
end)

Remotes.GetProfile.OnServerInvoke = function(player: Player)
	local profile = profiles[player]
	if not profile then
		return nil
	end
	return { coins = profile.coins, job = profile.job, vehiclesOwned = profile.vehiclesOwned }
end
