--!strict
-- JobService (Script) -> ServerScriptService/JobService
-- Banen kiezen, taken afronden en uitbetalen.

local Players = game:GetService("Players")
local MarketplaceService = game:GetService("MarketplaceService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local GameConfig = require(ReplicatedStorage:WaitForChild("GameConfig"))
local Remotes = require(ReplicatedStorage:WaitForChild("Remotes"))

local lastTask: { [Player]: number } = {}

local function hasVip(player: Player): boolean
	local id = GameConfig.Gamepasses.VIP.Id
	if id == 0 then
		return false
	end
	local ok, owns = pcall(function()
		return MarketplaceService:UserOwnsGamePassAsync(player.UserId, id)
	end)
	return ok and owns
end

Remotes.ChooseJob.OnServerEvent:Connect(function(player, jobId)
	if typeof(jobId) ~= "string" then
		return
	end
	local job = GameConfig.Jobs[jobId]
	if not job then
		return
	end
	local profile = _G.IamGetProfile(player)
	if not profile then
		return
	end
	profile.job = jobId
	Remotes.JobChanged:FireClient(player, jobId)
	Remotes.Notify:FireClient(player, ("Je werkt nu als %s!"):format(job.Display))
end)

Remotes.QuitJob.OnServerEvent:Connect(function(player)
	local profile = _G.IamGetProfile(player)
	if not profile then
		return
	end
	profile.job = nil
	Remotes.JobChanged:FireClient(player, nil)
	Remotes.Notify:FireClient(player, "Je bent gestopt met werken. Fijne vrije dag!")
end)

-- De client meldt dat een taak klaar is; de server checkt de cooldown en betaalt.
-- Belangrijk: de server bepaalt het bedrag, nooit de client.
Remotes.CompleteTask.OnServerEvent:Connect(function(player)
	local profile = _G.IamGetProfile(player)
	if not profile or not profile.job then
		return
	end
	local job = GameConfig.Jobs[profile.job]
	if not job then
		return
	end

	local now = os.clock()
	if lastTask[player] and now - lastTask[player] < job.Cooldown then
		return
	end
	lastTask[player] = now

	local pay = job.Pay
	if hasVip(player) then
		pay *= GameConfig.VipMultiplier
	end
	_G.IamAddCoins(player, pay)
	Remotes.Notify:FireClient(player, ("+%d %s"):format(pay, GameConfig.Currency.Name))
end)

Players.PlayerRemoving:Connect(function(player)
	lastTask[player] = nil
end)
