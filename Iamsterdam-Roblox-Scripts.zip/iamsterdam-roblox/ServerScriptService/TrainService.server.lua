--!strict
-- TrainService (Script) -> ServerScriptService/TrainService
-- Laat de NS-sprinter automatisch rondrijden langs de stations.
-- Verwacht: workspace.Trein (Model met PrimaryPart) en
--           workspace.Trein_Stations.<Naam> (Parts, in de volgorde uit GameConfig)

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")

local GameConfig = require(ReplicatedStorage:WaitForChild("GameConfig"))

local train = workspace:WaitForChild("Trein") :: Model
local stationsFolder = workspace:WaitForChild("Trein_Stations")

local function stationCFrame(name: string): CFrame?
	local part = stationsFolder:FindFirstChild(name) :: BasePart?
	return part and part.CFrame or nil
end

local function driveTo(target: CFrame)
	local current = train:GetPivot()
	local distance = (target.Position - current.Position).Magnitude
	local duration = math.max(distance / GameConfig.Train.Speed, 0.1)

	local proxy = Instance.new("CFrameValue")
	proxy.Value = current
	local connection = proxy.Changed:Connect(function(value)
		train:PivotTo(value)
	end)

	local tween = TweenService:Create(
		proxy,
		TweenInfo.new(duration, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut),
		{ Value = target }
	)
	tween:Play()
	tween.Completed:Wait()
	connection:Disconnect()
	proxy:Destroy()
end

task.spawn(function()
	-- Zorg dat alle onderdelen meebewegen: anchor alles en gebruik PivotTo.
	for _, descendant in train:GetDescendants() do
		if descendant:IsA("BasePart") then
			descendant.Anchored = true
		end
	end

	while true do
		for _, stationName in GameConfig.Train.Stations do
			local cf = stationCFrame(stationName)
			if cf then
				driveTo(cf)
				task.wait(GameConfig.Train.DwellSeconds)
			else
				warn("[I'amsterdam] Station ontbreekt: " .. stationName)
				task.wait(1)
			end
		end
		-- Terug naar het begin (de lijn rijdt heen en weer)
		for index = #GameConfig.Train.Stations - 1, 2, -1 do
			local cf = stationCFrame(GameConfig.Train.Stations[index])
			if cf then
				driveTo(cf)
				task.wait(GameConfig.Train.DwellSeconds)
			end
		end
	end
end)
