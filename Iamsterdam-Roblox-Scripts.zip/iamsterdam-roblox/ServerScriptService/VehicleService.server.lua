--!strict
-- VehicleService (Script) -> ServerScriptService/VehicleService
-- Spawnt fietsen, bootjes en karretjes. Eén voertuig per speler tegelijk.
-- Verwacht: ServerStorage/Vehicles/<Model> en workspace.VehicleSpawns.<Zone>

local Players = game:GetService("Players")
local ServerStorage = game:GetService("ServerStorage")
local MarketplaceService = game:GetService("MarketplaceService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Debris = game:GetService("Debris")

local GameConfig = require(ReplicatedStorage:WaitForChild("GameConfig"))
local Remotes = require(ReplicatedStorage:WaitForChild("Remotes"))

local active: { [Player]: Model } = {}
local lastSpawn: { [Player]: number } = {}

local function ownsPass(player: Player, passId: number): boolean
	if passId == 0 then
		return false
	end
	local ok, owns = pcall(function()
		return MarketplaceService:UserOwnsGamePassAsync(player.UserId, passId)
	end)
	return ok and owns
end

local function cooldownFor(player: Player): number
	if ownsPass(player, GameConfig.Gamepasses.SkipWachttijd.Id) then
		return 0
	end
	return GameConfig.VehicleCooldownSeconds
end

local function spawnPoint(player: Player): CFrame
	local character = player.Character
	local root = character and character:FindFirstChild("HumanoidRootPart") :: BasePart?
	if root then
		return root.CFrame * CFrame.new(0, 0, -8)
	end
	return CFrame.new(0, 10, 0)
end

Remotes.SpawnVehicle.OnServerEvent:Connect(function(player, vehicleId)
	if typeof(vehicleId) ~= "string" then
		return
	end
	local config = GameConfig.Vehicles[vehicleId]
	if not config then
		return
	end

	local now = os.clock()
	if lastSpawn[player] and now - lastSpawn[player] < cooldownFor(player) then
		Remotes.Notify:FireClient(player, "Even wachten voordat je een nieuw voertuig oproept.")
		return
	end

	local profile = _G.IamGetProfile(player)
	if not profile then
		return
	end

	-- Toegangscontrole: gamepass, gekocht, of gratis
	if config.GamepassId ~= nil then
		local passId = config.GamepassId
		if passId == 0 then
			passId = (GameConfig.Gamepasses[vehicleId] and GameConfig.Gamepasses[vehicleId].Id) or 0
		end
		if not ownsPass(player, passId) then
			Remotes.PromptGamepass:FireClient(player, passId)
			return
		end
	elseif config.Price > 0 and not profile.vehiclesOwned[vehicleId] then
		if not _G.IamSpendCoins(player, config.Price) then
			Remotes.Notify:FireClient(player, "Je hebt nog niet genoeg " .. GameConfig.Currency.Name .. ".")
			return
		end
		profile.vehiclesOwned[vehicleId] = true
	end

	local template = ServerStorage:FindFirstChild("Vehicles")
	template = template and template:FindFirstChild(config.Model)
	if not template then
		warn("[I'amsterdam] Model ontbreekt in ServerStorage/Vehicles: " .. config.Model)
		return
	end

	if active[player] then
		active[player]:Destroy()
	end

	local vehicle = (template :: Model):Clone()
	vehicle:PivotTo(spawnPoint(player))
	vehicle:SetAttribute("OwnerUserId", player.UserId)
	vehicle.Parent = workspace:FindFirstChild("SpawnedVehicles") or workspace
	active[player] = vehicle
	lastSpawn[player] = now

	Debris:AddItem(vehicle, GameConfig.VehicleDespawnSeconds)
	Remotes.Notify:FireClient(player, config.Display .. " staat voor je klaar!")
end)

Remotes.DespawnVehicle.OnServerEvent:Connect(function(player)
	if active[player] then
		active[player]:Destroy()
		active[player] = nil
	end
end)

Players.PlayerRemoving:Connect(function(player)
	if active[player] then
		active[player]:Destroy()
	end
	active[player] = nil
	lastSpawn[player] = nil
end)
