--!strict
-- JobBoardSetup (Script) -> ServerScriptService/JobBoardSetup
-- Zet automatisch een ProximityPrompt op elke bordjespaal en koppelt de baan.
-- Verwacht: workspace.Banenpalen met Parts die een StringValue "JobId" bevatten
--           (of een Part waarvan de naam gelijk is aan de JobId uit GameConfig).

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local GameConfig = require(ReplicatedStorage:WaitForChild("GameConfig"))
local Remotes = require(ReplicatedStorage:WaitForChild("Remotes"))

local folder = workspace:WaitForChild("Banenpalen")

-- De server wijst de baan direct toe (veiliger dan via de client).
local function setupPole(part: Instance)
	if not part:IsA("BasePart") then
		return
	end
	local idValue = part:FindFirstChild("JobId") :: StringValue?
	local jobId = idValue and idValue.Value or part.Name
	local job = GameConfig.Jobs[jobId]
	if not job then
		return
	end

	local prompt = part:FindFirstChildOfClass("ProximityPrompt") or Instance.new("ProximityPrompt")
	prompt.ActionText = "Word " .. job.Display
	prompt.ObjectText = "Banenpaal"
	prompt.HoldDuration = 0.5
	prompt.MaxActivationDistance = 12
	prompt.RequiresLineOfSight = false
	prompt.Parent = part

	prompt.Triggered:Connect(function(player)
		local profile = _G.IamGetProfile(player)
		if not profile then
			return
		end
		profile.job = jobId
		Remotes.JobChanged:FireClient(player, jobId)
		Remotes.Notify:FireClient(player, ("Je werkt nu als %s!"):format(job.Display))
	end)
end

for _, child in folder:GetChildren() do
	setupPole(child)
end
folder.ChildAdded:Connect(setupPole)
