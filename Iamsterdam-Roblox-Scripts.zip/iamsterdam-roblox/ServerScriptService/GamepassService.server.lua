--!strict
-- GamepassService (Script) -> ServerScriptService/GamepassService
-- Verkoopprompts, en het uitdelen van de voordelen zodra iemand koopt.

local Players = game:GetService("Players")
local MarketplaceService = game:GetService("MarketplaceService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local GameConfig = require(ReplicatedStorage:WaitForChild("GameConfig"))
local Remotes = require(ReplicatedStorage:WaitForChild("Remotes"))

local function passKeyById(passId: number): string?
	for keyName, info in GameConfig.Gamepasses do
		if info.Id == passId then
			return keyName
		end
	end
	return nil
end

local function applyBenefits(player: Player, passKey: string)
	local character = player.Character
	if passKey == "VIP" then
		player:SetAttribute("VIP", true)
	elseif passKey == "VliegendeZwaan" or passKey == "Tulpenfiets" or passKey == "Suikerspinkar" then
		player:SetAttribute("Unlocked_" .. passKey, true)
	elseif passKey == "GoudenGrachtenpand" or passKey == "VillaRingvaart" or passKey == "SnoepPenthouse" or passKey == "Woonboot" then
		player:SetAttribute("House_" .. passKey, true)
	elseif passKey == "ExtraHuisslot" then
		player:SetAttribute("HouseSlots", 2)
	end
	if character then
		-- Hier kun je accessoires of huisdieren aan het character hangen.
	end
	Remotes.Notify:FireClient(player, "Bedankt! " .. GameConfig.Gamepasses[passKey].Display .. " is nu van jou.")
end

local function refreshAll(player: Player)
	for passKey, info in GameConfig.Gamepasses do
		if info.Id ~= 0 then
			local ok, owns = pcall(function()
				return MarketplaceService:UserOwnsGamePassAsync(player.UserId, info.Id)
			end)
			if ok and owns then
				applyBenefits(player, passKey)
			end
		end
	end
end

Players.PlayerAdded:Connect(function(player)
	task.spawn(refreshAll, player)
	player.CharacterAdded:Connect(function()
		task.wait(1)
		refreshAll(player)
	end)
end)

Remotes.PromptGamepass.OnServerEvent:Connect(function(player, passId)
	if typeof(passId) ~= "number" or passId == 0 then
		Remotes.Notify:FireClient(player, "Deze pass is nog niet beschikbaar.")
		return
	end
	MarketplaceService:PromptGamePassPurchase(player, passId)
end)

MarketplaceService.PromptGamePassPurchaseFinished:Connect(function(player, passId, wasPurchased)
	if not wasPurchased then
		return
	end
	local passKey = passKeyById(passId)
	if passKey then
		applyBenefits(player, passKey)
	end
end)

Remotes.GetOwnedPasses.OnServerInvoke = function(player: Player)
	local owned = {}
	for passKey, info in GameConfig.Gamepasses do
		owned[passKey] = info.Id ~= 0 and player:GetAttribute("Unlocked_" .. passKey) == true or false
	end
	return owned
end
