--!strict
-- BridgeService (Script) -> ServerScriptService/BridgeService
-- De Zwanenburgse ophaalbrug: gaat elke paar minuten open en weer dicht.
-- Verwacht: workspace.Ophaalbrug.Dek (BasePart, PrimaryPart van het brugdeel)
--           workspace.Ophaalbrug.Scharnier (BasePart, het draaipunt)

local TweenService = game:GetService("TweenService")

local bridge = workspace:WaitForChild("Ophaalbrug")
local deck = bridge:WaitForChild("Dek") :: BasePart
local hinge = bridge:WaitForChild("Scharnier") :: BasePart

local CLOSED = deck.CFrame
local OPEN_ANGLE = math.rad(72)
local INTERVAL = 180
local OPEN_DURATION = 25

local function moveDeck(angle: number, seconds: number)
	local pivot = hinge.CFrame
	local relative = pivot:ToObjectSpace(CLOSED)
	local target = pivot * CFrame.Angles(angle, 0, 0) * relative

	local proxy = Instance.new("CFrameValue")
	proxy.Value = deck.CFrame
	local connection = proxy.Changed:Connect(function(value)
		deck.CFrame = value
	end)
	local tween = TweenService:Create(
		proxy,
		TweenInfo.new(seconds, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut),
		{ Value = target }
	)
	tween:Play()
	tween.Completed:Wait()
	connection:Disconnect()
	proxy:Destroy()
end

deck.Anchored = true
hinge.Anchored = true

task.spawn(function()
	while true do
		task.wait(INTERVAL)
		moveDeck(OPEN_ANGLE, 4)
		task.wait(OPEN_DURATION)
		moveDeck(0, 4)
	end
end)
