local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local MarketplaceService = game:GetService("MarketplaceService")

local Modules = script.Parent:WaitForChild("Modules")
local Config = require(Modules:WaitForChild("GameConfig"))
local PlayerData = require(Modules:WaitForChild("PlayerData"))

local remotes = ReplicatedStorage:FindFirstChild("Remotes") or Instance.new("Folder")
remotes.Name = "Remotes"
remotes.Parent = ReplicatedStorage

local function remote(className, name)
    local item = remotes:FindFirstChild(name) or Instance.new(className)
    item.Name = name
    item.Parent = remotes
    return item
end

local Notify = remote("RemoteEvent", "Notify")
local SpawnVehicle = remote("RemoteEvent", "SpawnVehicle")
local BuyHouse = remote("RemoteEvent", "BuyHouse")
local OpenPassPrompt = remote("RemoteEvent", "OpenPassPrompt")
local CompleteJobTask = remote("RemoteEvent", "CompleteJobTask")
local GetProfile = remote("RemoteFunction", "GetProfile")

local activeVehicles = {}

local function ownsPass(player, passKey)
    local id = Config.Gamepasses[passKey]
    if not id or id <= 0 then return false end
    local ok, owned = pcall(MarketplaceService.UserOwnsGamePassAsync, MarketplaceService, player.UserId, id)
    return ok and owned
end

local function setCoins(player, newValue)
    local data = PlayerData.Get(player)
    if not data then return end
    data.Coins = math.max(0, math.floor(newValue))
    local stats = player:FindFirstChild("leaderstats")
    if stats then stats.Coins.Value = data.Coins end
end

local function addCoins(player, amount)
    local data = PlayerData.Get(player)
    if data then setCoins(player, data.Coins + amount) end
end

local function destroyVehicle(player)
    local vehicle = activeVehicles[player.UserId]
    if vehicle then vehicle:Destroy() end
    activeVehicles[player.UserId] = nil
end

Players.PlayerAdded:Connect(function(player)
    local data = PlayerData.Load(player)
    local stats = Instance.new("Folder")
    stats.Name = "leaderstats"
    stats.Parent = player
    local coins = Instance.new("IntValue")
    coins.Name = "Coins"
    coins.Value = data.Coins
    coins.Parent = stats

    local today = os.date("!%Y-%m-%d")
    if data.LastLogin ~= today then
        data.LastLogin = today
        addCoins(player, Config.DailyBonus)
        task.defer(function() Notify:FireClient(player, "Dagelijkse bonus: +" .. Config.DailyBonus .. " coins") end)
    end
end)

Players.PlayerRemoving:Connect(function(player)
    destroyVehicle(player)
    PlayerData.Save(player)
    PlayerData.Remove(player)
end)

task.spawn(function()
    while task.wait(Config.AutosaveSeconds) do
        for _, player in ipairs(Players:GetPlayers()) do PlayerData.Save(player) end
    end
end)

GetProfile.OnServerInvoke = function(player)
    local data = PlayerData.Get(player)
    if not data then return {} end
    return {Coins = data.Coins, CurrentJob = data.CurrentJob, Stats = data.Stats, Achievements = data.UnlockedAchievements}
end

SpawnVehicle.OnServerEvent:Connect(function(player, vehicleName)
    local rule = Config.Vehicles[vehicleName]
    if not rule then return end
    if rule.Premium and not ownsPass(player, rule.PassKey) then
        Notify:FireClient(player, "Voor dit voertuig heb je de bijbehorende gamepass nodig.")
        return
    end
    local folder = ServerStorage:FindFirstChild("VehicleModels")
    local template = folder and folder:FindFirstChild(vehicleName)
    local spawnPart = workspace:FindFirstChild("VehicleSpawn")
    if not template or not template:IsA("Model") or not template.PrimaryPart or not spawnPart then
        Notify:FireClient(player, "Voertuig of VehicleSpawn ontbreekt nog in de map.")
        return
    end
    destroyVehicle(player)
    local vehicle = template:Clone()
    vehicle:PivotTo(spawnPart.CFrame * CFrame.new(0, 3, 0))
    vehicle.Parent = workspace
    activeVehicles[player.UserId] = vehicle
    task.delay(Config.VehicleLifetimeSeconds, function()
        if activeVehicles[player.UserId] == vehicle then destroyVehicle(player) end
    end)
end)

OpenPassPrompt.OnServerEvent:Connect(function(player, passKey)
    local id = Config.Gamepasses[passKey]
    if not id or id <= 0 then
        Notify:FireClient(player, "Deze gamepass heeft nog geen echte ID. Vul die eerst in GameConfig in.")
        return
    end
    MarketplaceService:PromptGamePassPurchase(player, id)
end)

BuyHouse.OnServerEvent:Connect(function(player, houseId)
    local definition = Config.Houses[houseId]
    local data = PlayerData.Get(player)
    if not definition or not data then return end
    if definition.PassKey and not ownsPass(player, definition.PassKey) then
        Notify:FireClient(player, "Voor dit huis heb je eerst de bijbehorende gamepass nodig.")
        return
    end
    if data.Coins < definition.Price then
        Notify:FireClient(player, "Je hebt " .. definition.Price .. " coins nodig.")
        return
    end
    setCoins(player, data.Coins - definition.Price)
    table.insert(data.OwnedHouses, houseId)
    Notify:FireClient(player, "Je hebt " .. houseId .. " gekocht!")
end)

-- Exporteer uitsluitend serverfuncties voor JobService.
_G.Iamsterdam = {AddCoins = addCoins, Notify = function(p, t) Notify:FireClient(p, t) end, Config = Config, Data = PlayerData}
