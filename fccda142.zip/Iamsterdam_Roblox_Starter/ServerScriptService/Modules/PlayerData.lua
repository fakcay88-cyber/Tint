local DataStoreService = game:GetService("DataStoreService")
local store = DataStoreService:GetDataStore("IamsterdamPlayerData_v1")

local PlayerData = {}
local cache = {}

local DEFAULT = {
    Coins = 250,
    LastLogin = "",
    CurrentJob = "",
    OwnedHouses = {},
    Stats = {Tasks = 0},
    UnlockedAchievements = {},
}

local function clone(value)
    if type(value) ~= "table" then return value end
    local result = {}
    for k, v in pairs(value) do result[k] = clone(v) end
    return result
end

function PlayerData.Load(player)
    local data
    local ok, result = pcall(function()
        return store:GetAsync("u_" .. player.UserId)
    end)
    if ok and type(result) == "table" then data = result else data = clone(DEFAULT) end
    for key, value in pairs(DEFAULT) do
        if data[key] == nil then data[key] = clone(value) end
    end
    cache[player.UserId] = data
    return data
end

function PlayerData.Get(player)
    return cache[player.UserId]
end

function PlayerData.Save(player)
    local data = cache[player.UserId]
    if not data then return true end
    local ok, err = pcall(function()
        store:UpdateAsync("u_" .. player.UserId, function() return data end)
    end)
    if not ok then warn("Save failed for", player.Name, err) end
    return ok
end

function PlayerData.Remove(player)
    cache[player.UserId] = nil
end

return PlayerData
