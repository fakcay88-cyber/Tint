local Config = {}

Config.StartingCoins = 250
Config.DailyBonus = 100
Config.AutosaveSeconds = 120
Config.VehicleLifetimeSeconds = 600

Config.Jobs = {
    Bakker = {DisplayName = "Bakker", Reward = 15},
    Conducteur = {DisplayName = "NS-conducteur", Reward = 20},
    Politieagent = {DisplayName = "Politieagent", Reward = 18},
    IJsverkoper = {DisplayName = "IJsverkoper", Reward = 12},
}

Config.Vehicles = {
    Bakfiets = {Premium = false},
    Stadsfiets = {Premium = false},
    Grachtenbootje = {Premium = false},
    Pannenkoekenboot = {Premium = true, PassKey = "Pannenkoekenboot"},
}

-- Vervang 0 alleen door de pass-ID uit jouw eigen Creator Dashboard.
Config.Gamepasses = {
    Grachtenpand = 0,
    ZwanenburgVilla = 0,
    Pannenkoekenboot = 0,
    NederlandsKledingpakket = 0,
    VIP = 0,
}

Config.Houses = {
    StarterHuisje = {Price = 0, PassKey = nil},
    Grachtenpand = {Price = 5000, PassKey = "Grachtenpand"},
    ZwanenburgVilla = {Price = 8000, PassKey = "ZwanenburgVilla"},
}

Config.Achievements = {
    EersteTaak = {Stat = "Tasks", Target = 1, Reward = 50, Label = "Eerste werktaak"},
    TienTaken = {Stat = "Tasks", Target = 10, Reward = 150, Label = "10 werktaken"},
    VijftigTaken = {Stat = "Tasks", Target = 50, Reward = 500, Label = "50 werktaken"},
}

return Config
