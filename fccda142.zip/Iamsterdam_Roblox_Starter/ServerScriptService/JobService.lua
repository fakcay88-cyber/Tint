local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local CompleteJobTask = Remotes:WaitForChild("CompleteJobTask")

local function has(list, value)
    for _, entry in ipairs(list) do if entry == value then return true end end
    return false
end

local function setJob(player, jobName)
    local api = _G.Iamsterdam
    if not api or not api.Config.Jobs[jobName] then return end
    local data = api.Data.Get(player)
    if not data then return end
    data.CurrentJob = jobName
    api.Notify(player, "Je bent nu " .. api.Config.Jobs[jobName].DisplayName .. "!")
end

local stations = workspace:FindFirstChild("JobStations")
if stations then
    for _, station in ipairs(stations:GetChildren()) do
        local prompt = station:FindFirstChildOfClass("ProximityPrompt")
        if prompt then
            prompt.ActionText = "Kies baan"
            prompt.ObjectText = station.Name
            prompt.Triggered:Connect(function(player) setJob(player, station.Name) end)
        end
    end
else
    warn("Maak Workspace.JobStations aan voor de banen.")
end

CompleteJobTask.OnServerEvent:Connect(function(player, claimedJob)
    local api = _G.Iamsterdam
    if not api then return end
    local data = api.Data.Get(player)
    local job = api.Config.Jobs[claimedJob]
    if not data or not job or data.CurrentJob ~= claimedJob then return end
    -- In productie: valideer ook fysieke afstand, cooldown en taakstatus op de server.
    api.AddCoins(player, job.Reward)
    data.Stats.Tasks = (data.Stats.Tasks or 0) + 1
    api.Notify(player, "+" .. job.Reward .. " coins voor je werk als " .. job.DisplayName)
    for id, achievement in pairs(api.Config.Achievements) do
        if achievement.Stat == "Tasks" and data.Stats.Tasks >= achievement.Target and not has(data.UnlockedAchievements, id) then
            table.insert(data.UnlockedAchievements, id)
            api.AddCoins(player, achievement.Reward)
            api.Notify(player, "Achievement: " .. achievement.Label .. " ( +" .. achievement.Reward .. " coins )")
        end
    end
end)
