# I'amsterdam — Roblox Studio Starterpakket

Dit zip-bestand bevat een werkend **script-startpakket** voor een kindvriendelijke Roblox roleplay-game. Het is geen kant-en-klare `.rbxl`-wereld: de 3D-map, modellen, geluiden, gamepass-ID's en publicatie moeten in Roblox Studio worden gedaan. De scripts geven je een veilige basis voor coins, banen, voertuigen, een shop, huizen, quests en UI.

## Snel installeren

1. Maak in Roblox Studio een nieuw **Baseplate**-project.
2. Kopieer de mappen uit dit pakket naar dezelfde locaties in de Explorer.
3. Plaats `GameConfig` en `PlayerData` als **ModuleScript** in `ServerScriptService > Modules`.
4. Plaats `ServerBootstrap` en `JobService` als gewone **Script** in `ServerScriptService`.
5. Plaats `ClientMain` als **LocalScript** in `StarterPlayer > StarterPlayerScripts`.
6. Maak de modellen/folders aan die hieronder worden vermeld.
7. Test eerst met **Play**. Zet pas daarna DataStore API Services aan via Game Settings > Security.

## Vereiste structuur in Studio

```text
ServerScriptService
  Modules
    GameConfig (ModuleScript)
    PlayerData (ModuleScript)
  ServerBootstrap (Script)
  JobService (Script)
StarterPlayer
  StarterPlayerScripts
    ClientMain (LocalScript)
ServerStorage
  VehicleModels
    Bakfiets (Model met PrimaryPart)
    Stadsfiets (Model met PrimaryPart)
    Grachtenbootje (Model met PrimaryPart)
Workspace
  JobStations (Folder)
    Bakker (Part met ProximityPrompt)
    Conducteur (Part met ProximityPrompt)
    Politieagent (Part met ProximityPrompt)
    IJsverkoper (Part met ProximityPrompt)
  VehicleSpawn (Part)
  Huizen (Folder)
    [elk huis is Model met Attributes: HouseId en OwnerUserId]
```

## Map interactief maken

### Banen
Plaats in `Workspace.JobStations` een Part met exact één `ProximityPrompt` per baan. Noem elk object exact als een baan in `GameConfig.Jobs`: `Bakker`, `Conducteur`, `Politieagent` of `IJsverkoper`.

Voor een taak plaats je een `ProximityPrompt` op een werkplek en voeg je een **Attribute** `JobTask` toe met bijvoorbeeld `Bakker`. Voeg vervolgens een Script onder die prompt toe:

```lua
local prompt = script.Parent
prompt.Triggered:Connect(function(player)
    game.ReplicatedStorage.Remotes.CompleteJobTask:FireServer(prompt:GetAttribute("JobTask"))
end)
```

Gebruik in een echte live-game liever het meegeleverde `CompleteJobTask` remote vanuit de client of maak per interactie server-validatie; vertrouw nooit alleen een client voor coin-beloningen.

### Voertuigen
Plaats voertuig-Modellen in `ServerStorage.VehicleModels`. Elke Model heeft een `PrimaryPart` nodig. Voeg fysica/VehicleSeats zelf toe aan het model. De server spawn één voertuig per speler bij `Workspace.VehicleSpawn`.

### Huizen
Maak in elk huis-model een ProximityPrompt bij het koopbord. Zet een String Attribute `HouseId` op het huis-model, bijvoorbeeld `StarterHuisje`. Sluit de prompt via een klein serverscript aan op `Remotes.BuyHouse`.

## Gamepasses
Maak passes alleen aan via Creator Dashboard. Vul daarna de echte numerieke IDs in bij `GameConfig.Gamepasses`. De voorbeeldwaarden zijn bewust `0`; een prompt opent dan niet. Vermijd pay-to-win: de passes in dit pakket zijn vooral cosmetisch of comfortgericht.

## Veiligheid en publicatie

- Houd chat, namen, decor en quests kindvriendelijk.
- Gebruik geen echte logo's, merknamen, assets of muziek zonder toestemming/licentie.
- Voeg duidelijke spelregels en meldmogelijkheden toe.
- Test dat spelers geen coins kunnen krijgen door RemoteEvents te misbruiken.
- Publiceer eerst privé en test met vrienden voordat je publiek gaat.
