local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local player = Players.LocalPlayer
local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Notify = Remotes:WaitForChild("Notify")
local GetProfile = Remotes:WaitForChild("GetProfile")

local gui = Instance.new("ScreenGui")
gui.Name = "IamsterdamUI"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local function rounded(instance, pixels)
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, pixels)
    corner.Parent = instance
end

local coins = Instance.new("TextLabel")
coins.Size = UDim2.fromOffset(190, 44)
coins.Position = UDim2.fromOffset(18, 18)
coins.BackgroundColor3 = Color3.fromRGB(245, 130, 25)
coins.TextColor3 = Color3.new(1,1,1)
coins.Font = Enum.Font.GothamBold
coins.TextSize = 18
coins.Parent = gui
rounded(coins, 12)

local message = Instance.new("TextLabel")
message.Size = UDim2.fromOffset(420, 45)
message.Position = UDim2.new(0.5, -210, 0, 18)
message.BackgroundColor3 = Color3.fromRGB(40, 40, 50)
message.TextColor3 = Color3.new(1,1,1)
message.Font = Enum.Font.GothamMedium
message.TextSize = 15
message.TextWrapped = true
message.Visible = false
message.Parent = gui
rounded(message, 12)

local function updateCoins()
    local leaderstats = player:FindFirstChild("leaderstats")
    local value = leaderstats and leaderstats:FindFirstChild("Coins")
    coins.Text = "🪙 " .. tostring(value and value.Value or 0) .. " coins"
end

task.spawn(function()
    local stats = player:WaitForChild("leaderstats")
    stats:WaitForChild("Coins"):GetPropertyChangedSignal("Value"):Connect(updateCoins)
    updateCoins()
end)

Notify.OnClientEvent:Connect(function(text)
    message.Text = tostring(text)
    message.Visible = true
    task.delay(3, function() message.Visible = false end)
end)

local vehicles = {"Bakfiets", "Stadsfiets", "Grachtenbootje", "Pannenkoekenboot"}
local button = Instance.new("TextButton")
button.Size = UDim2.fromOffset(150, 42)
button.Position = UDim2.fromOffset(18, 72)
button.BackgroundColor3 = Color3.fromRGB(0, 153, 105)
button.TextColor3 = Color3.new(1,1,1)
button.Text = "🚲 Spawn bakfiets"
button.Font = Enum.Font.GothamBold
button.TextSize = 15
button.Parent = gui
rounded(button, 12)

local index = 1
button.MouseButton1Click:Connect(function()
    Remotes.SpawnVehicle:FireServer(vehicles[index])
    index = index % #vehicles + 1
    button.Text = "Spawn: " .. vehicles[index]
end)
