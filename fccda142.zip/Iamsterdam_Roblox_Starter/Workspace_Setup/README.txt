Maak deze objecten handmatig in Roblox Studio:

1. Workspace > Folder: JobStations
2. Voeg Parts toe: Bakker, Conducteur, Politieagent, IJsverkoper.
3. Voeg onder elke Part een ProximityPrompt toe.
4. Workspace > Part: VehicleSpawn.
5. Workspace > Folder: Huizen.
6. ServerStorage > Folder: VehicleModels; zet voertuig-Modellen hierin met PrimaryPart.

Dit zijn bewust geen geleende Roblox/merk-assets. Bouw of gebruik uitsluitend modellen, audio en afbeeldingen waarvoor je de rechten hebt.
